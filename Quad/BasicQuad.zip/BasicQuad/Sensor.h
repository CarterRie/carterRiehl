#ifndef SENSOR_H
#define SENSOR_H

class Sensor(){
    // declarations go here!
    // So does data.
};

#endif